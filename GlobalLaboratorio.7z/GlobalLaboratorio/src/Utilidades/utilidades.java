package Utilidades;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class utilidades {
    //Cuando empece a escribir el programa me di cuenta que iva a tener que crear muchos arreglos de 6 elementos, asique cree esta utilidad
    //para acelerar el prosceso, toma 6 elementos dados por el usuario y devuelvo un arreglo con esos 6 elementos
    public static ArrayList<String> createArrayOf6Elements(String ele1,String ele2,String ele3,String ele4,String ele5,String ele6){
        ArrayList<String> arr=new ArrayList<String>();
        arr.add(ele1);
        arr.add(ele2);
        arr.add(ele3);
        arr.add(ele4);
        arr.add(ele5);
        arr.add(ele6);
        return arr;
    }
    //Cuando escribo programas uso mucho este formato para preguntar cosas al usuario, asique cree una funcion para
    //acelerar el prosceso de preguntar
    public static boolean askUser(String promt){
        Scanner input=new Scanner(System.in);
        int rep;
        System.out.println(promt+"\n[1].Si\n[2].No");
        while (true){
            rep=input.nextInt();
            if (rep==1){
                return true;
            } else if (rep==2) {
                return false;
            }else {
                System.out.println("Valor, no valido, intente denuevo");
            }
        }

    }
    //Utilidad para mostrar un arreglo en forma de tabla, util para testeo y para el programa principal
    public static void showArray(ArrayList<ArrayList <String>> arr){
       for (ArrayList <String> i:arr){
           System.out.println(i);
       }
    }
    //Esta es la opcion 1 del menu principal, es un simple menu pequeño con solo 2 opciones, usa un while true para que el
    //usuario no ingrese un valor no valido
    public static ArrayList<String> option1(){
        int rep;
        Scanner input=new Scanner(System.in);
        ArrayList<String> dna=new ArrayList<>();
        while (true){
            System.out.println("¿Que secuencia desea usar?\n[1].Wolverine(mutante)\n[2].EmilioBaigorria(no mutante)");
            rep=input.nextInt();
            if (rep==1){
                dna=createArrayOf6Elements("AAAATC","CGTATA","CATGCA","CCGTTC","CGTATC","CAGTGT");
                return dna;
            } else if (rep==2) {
                dna=createArrayOf6Elements("AAGATC","CGTATA","TATGCA","CCGTPC","CGTATC","CAATGT");
                return dna;
            }else {
                System.out.println("Numero no valido, intente denuevo\n");
            }
        }
    }
    //#Esta es la opcion 2 del menu
    public static ArrayList<String> option2(){
        Scanner input=new Scanner(System.in);
        ArrayList<String> dnaArr=new ArrayList<String>();
        String temp_sec;
        for (int i=0;i<6;i++){//Se deben ingresar 6 filas por lo que todas las comprobacicones se deben pasar 6 veces
            while (true){
                System.out.println("Ingrese la secuencia, recuerde que la secuencia debe tener almenos 6 caracteres y que estos deben ser A,T,C o G ("+(i+1)+"/6)\n");
                temp_sec=input.nextLine();
                if (option2_6chars(temp_sec) && option2_AddmitedChars(temp_sec)){ //Para simplificar el prosceso de la comprobacion cree otras 2 subfunciones
                                                                                  //la primera comprueba si el elemento ingresado tiene 6 chars, la segunda revisa que los
                                                                                  //chars que componene la secuencia esten dentro de los chars admitidos
                    break;
                }else {
                    System.out.println("La secuencia no es valida, intente denuevo");
                }
            }
            dnaArr.add(temp_sec);//Si la comprobacion esta completa entonces se agrega el nuevo elemnto
        }
        return dnaArr;
    }
    //Comprueba si el elemento dado tiene 6 chars de largo
    public static boolean option2_6chars(String temp){
        if (temp.length()==6){
            return true;
        }else {
            return false;
        }
    }
    //Comprueba si el elemneto dado esta compuesto por los chars admitidos
    public static boolean option2_AddmitedChars(String temp){

        for (int i=0;i<temp.length();i++){
            if (temp.charAt(i)!='A' && temp.charAt(i)!='G' && temp.charAt(i)!='T' && temp.charAt(i)!='C'){
                return false;
            }
        }
        return true;
    }
    //-isMutant------------------------------
    //La subfuncion principal
    public static   boolean isMutant(ArrayList<String> dna){
        int p=0,mutantFactor=0;
        ArrayList<ArrayList<String>> dna_arr=new ArrayList<ArrayList<String>>();
        ArrayList<String>  temp_sec=new ArrayList<String>();
        for (String i:dna){//Primero convierto la lista de strigns ingresadas por el usuario en una matriz 6x6
            temp_sec=createArrayOf6Elements(String.valueOf(i.charAt(0)),String.valueOf(i.charAt(1)),String.valueOf(i.charAt(2)),String.valueOf(i.charAt(3)),String.valueOf(i.charAt(4)),String.valueOf(i.charAt(5)));
            dna_arr.add(temp_sec);
        }
        p=1;
        //La idea con este while es reducir al minimo la cantidad de recursos utilizados, en la primera pasada comprueba
        //las lineas horizontales, si el factor mutante es igual a 2 entonces, ya esta, no hace falta hacer mas pasadas y
        //se devuelve el true, en caso contrario se revisa la columnas y se hace el mismo check, de esta manera se reduce
        //la cantidad de veces que se tienen que pasar, si incluso despues de las 3 pasadas el factor mutante sigue siendo
        //menor a 2 entonces definitivamente no es un mutante y se devuelve false.
        while (mutantFactor<2){
            if (p==1){
                mutantFactor=horizontalMutant(dna_arr);
            } else if (p==2) {
                mutantFactor=mutantFactor+verticalMuntant(dna_arr);
                
            } else if (p==3) {
                mutantFactor=mutantFactor+diagonalMutant(dna_arr);
                
            }else {
                return false;
            }
            p++;
        }
        return true;

    }
    //-Horizontal------------------------------
    public static int horizontalMutant(ArrayList<ArrayList<String>> dnaArr){
        int mutantFactor=0,p=-1,i=-1,z=1;
        while (true){//Uso 2 while true y valores i,p para poder moverme por los valores de la lista
            i=i+1;
            p=-1;
            if (i==dnaArr.size()){
                break;
            }
            while (true){
                p=p+1;
                if (p==(dnaArr.size()-2)){
                    break;
                } else if (dnaArr.get(i).get(p).equals(dnaArr.get(i).get(p + 1))) {

                    if (horizontalCheck(dnaArr.get(i),p,z)){//Si devuelve true significa que que podemos aumentar el
                                                            //factor mutante en 1 y rompemos del segundo
                                                            //while true porque no podemos encontrar mas secuencias
                                                            //de cuatro letras iguales en la misma linea
                        mutantFactor++;
                        break;
                    }

                }
            }
        }
        return mutantFactor;
    }

    public static boolean horizontalCheck(ArrayList<String> array,int p, int z){//Esta funcion recursiva me permina comprobar si hay 4 letras iguales segudas
        if (z==4){//z representa la tandidad de letras seguidas, si z es igual a 4 siginica que hay 4 letrass seguidas iguales y devuelve true
            return true;
        } else if (p==array.size()-1) {//Si p es igual a 5 significa que ya no hay mas letras y dado a que no se cumplio la condicion anterior devuelve false
            return false;
        } else if (array.get(p).equals(array.get(p+1))) {//si la letra actual es igual a la letra siguiente entonces se vuelve a llamar a funcion
            return horizontalCheck(array,p+1,z+1);
        }else {
            return false;
        }

    }
    //-Vertical------------------------------
    //Mi estategia para resolver los problemas que vienen que la revision en vertical fue convertir las columnas en filas y viceversa
    //de esa manera puedo reciclar todo el codigo de la revision horizontal para obtener el factor  mutante de las columnas verticales
    public static int verticalMuntant(ArrayList<ArrayList<String>> array) {
        int mutantFactor = 0, p = 0;
        ArrayList<ArrayList<String>> transposedArray = new ArrayList<ArrayList<String>>();
        ArrayList<String> tempArray = new ArrayList<String>();
        for (int j = 0; j < array.size(); j++) {
            tempArray.clear();
            for (ArrayList<String> i : array) {//En esta parte tomo el todos los valores de cada columna, los voy guardando en una lista temp
                                               //y cuando los tengo todos los guardo en una nueva matriz que es la uso para la revision horizontal
                tempArray.add(i.get(p));
            }
            transposedArray.add(tempArray);
            p++;
        }
        mutantFactor=mutantFactor+horizontalMutant(transposedArray);//Final mente reciclo horizontalcheck y obtengo el factor mutante
        return mutantFactor;
    }
    //-Diagonal---------------------------
    //Mi estrategia para las diagonales es la misma que con las verticales, para eso cree 5 funciones

    //Esta es la principal, dado a que queria revisar la diagonales de izquierda a derecha y las de derecha a izquierda
    //al principio de todo creo una copia de la lista dada por el usuario pero dada vuelta, es decir pasa de "accb" a "bcca"
    public static int diagonalMutant(ArrayList<ArrayList<String>> array){
        int mutantFactor;
        ArrayList<ArrayList<String>> invertedArray=new ArrayList<ArrayList<String>>();

        for (ArrayList<String> i: array){//Aca es donde creo la lista invertida
            invertedArray.add(invertAux(i));
        }
        //Aca es donde obtengo el factor mutante final de las diagonales de izquierda a derecha y las de derecha a izquierda
        mutantFactor=horizontalMutant(diagonalMutantArray(array))+horizontalMutant(diagonalMutantArray(invertedArray));
        return mutantFactor;
    }
    //Esta subfuncion me ayuda a obtener las listas invertidas, por eso se llama invertAux
    public static ArrayList<String> invertAux(ArrayList<String> i){
        ArrayList<String> tempArray=new ArrayList<String>();
        for (int p=i.size()-1;p>-1;p--){
            tempArray.add(i.get(p));
        }
        return tempArray;
    }
    public static ArrayList<ArrayList<String>> diagonalMutantArray(ArrayList<ArrayList<String>> array){//Aca es de donde en obtengo la lista que que voy a usar para la revision horizontal

        ArrayList<ArrayList<String>> diagonalArray=new ArrayList<ArrayList<String>>();
        ArrayList<String> tempArray=new ArrayList<String>();
        for (int i=0;i<array.size();i++){//Primero obtengo todas las diagonales de las filas, por eso el valor de p es 0
            if (diagMaker(array,i,0).size()>3){  //Mientras mas nos acercamos a las esquinas mas pequeñas se hacen las listas
                                                    //y por tanto si una lista tiene menos de 4 elementos entonces no podemos obtener
                                                    //ningun gen mutante (porque hace falta 4 valores iguales seguidos)
                diagonalArray.add(diagMaker(array,i,0));
            }

        }
        for (int p=1;p<array.size();p++){//Aca consigo todas la diagonales que empiezan en las columnas(Exepto la primero porque eso ya se guardo),
                                         //por eso el valor de i es 0
            if (diagMaker(array,0,p).size()>3){
                diagonalArray.add(diagMaker(array,0,p));
            }
        }
        return diagonalArray;//Finalmente devuelvo la lista con todas las posibles diagonales en formate matriz

    }
    //Esta subfuncion me permite obtener la diagonal de la matriz que le pida,en si la la funcion no hace mucho pero
    //poniendo esto asi evito problemas, la que realmente hace el trabajo es diagonalToHorizontal
    public static ArrayList<String> diagMaker(ArrayList<ArrayList<String>> array,int i,int p){
        ArrayList<String> tempArray=new ArrayList<String>();
        ArrayList<String> finalList=new ArrayList<String>();
        tempArray=diagonalToHorizontal(array,i,p,finalList);
        return tempArray;
    }


    //Esta funcion es la que me permite crear listas verticales a partir de
    //diagonales, i y p son los putos de inicio de la diagnonal, es decir
    //si ponemos 0,0 entonces la lista creada es la diagonal resultante
    //de empezar en cordenada 0,0
    public static ArrayList<String> diagonalToHorizontal(ArrayList<ArrayList<String>> array,int i,int p,ArrayList<String> finalArray){
        if (i==array.size() || p==array.get(i).size()){
            return finalArray;
        }else {
            finalArray.add(array.get(i).get(p));
            return diagonalToHorizontal(array,i+1,p+1,finalArray);
        }
    }


}
