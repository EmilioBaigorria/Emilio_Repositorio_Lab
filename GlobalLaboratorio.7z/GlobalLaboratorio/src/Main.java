import java.util.ArrayList;
import java.util.Scanner;

import Utilidades.utilidades;
//-Casos de prueba-
// ["AAAATC","CGTATA","CATGCA","CCGTCC","CGTATC","CAGTGT"]  (Mutante)
//
// ["AAGATC","CGTATA","TATGCA","CCGTPC","CGTATC","CAATGT"]  (No mutante)
//Nota: Si prefiere, puede usar la opcion 1 en el menu principal para cargar los datos automaticamente, sin tener que hacerlo manualmente

public class Main {
    public static void main(String[] args) {
        boolean exit=false;
        int rep;
        Scanner input=new Scanner(System.in);
        ArrayList<String> dna=new ArrayList<String>();
        while (!exit){/*Utilizo un while para poder encargarme facilmente de errores ingresados por el usuario*/
            //Este es el menu principal, es lo primero que el usuario ve y esta hecho para que el usuario pueda decidir cuando salir
            System.out.println("Bienvendio magneto \n[1].Usar secuencia de adn pre-creada\n[2].Usar secuencia ingresada manualmente\n[3].Salir del programa\n");
            rep=input.nextInt();
            if (rep==1){
                dna=utilidades.option1();
            } else if (rep==2) {
                dna=utilidades.option2();
            } else if (rep==3) {
                break;

            }
            System.out.println("Secuencia del individuo:");
            for (String i:dna){
                System.out.println(i);
            }
            if (utilidades.isMutant(dna)){ //Dado a que is mutant devuelve un bool puedo utilizarlo directamente como la condicion
                System.out.println("Se trata de un mutante mi lord magneto");
            }else {
                System.out.println("Me temo que no es un mutante mi lord magneto\n");
            }

            if (utilidades.askUser("¿Desea analizar otra secuencia mi lord magneto?")){
                break;
            }

        }






    }
}